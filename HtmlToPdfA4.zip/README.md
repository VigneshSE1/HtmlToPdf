# Installation
- npm install
# Run
- node script.js